
//move to screen 2
function startQuiz() {
    const openQuiz= document.querySelector('#quiz');
    const hideIntro= document.querySelector('#introduction');
    openQuiz.classList.remove('hidden');
    hideIntro.classList.add('hidden');

    fetch('https://wpr-quiz-api.herokuapp.com/attempts',{
        method: 'POST',
    }).then(onResponse).then(function onJson(json){
        // attempt_id = json._id;
        const allQuestion = json.questions;
        console.log(allQuestion)
        const quest = allQuestion.map(function(question, index){
            return`<div id="${question._id}">
                <h2>Question ${index+1} of 10</h2>
                <p> ${question.text}</p>
                ${question.answers.map(function(answer, index1){
                    return`<label id="${index1}" class="option" onclick="highlight(event)">
                        <input type="radio" name="${question._id}" value="${index1}">&nbsp;${convert(answer)}
                    </label>`
                }).join('')}
            </div>`
        })
        let addQuestion= quest.join('');
        document.querySelector('#questions').innerHTML+=addQuestion;
    });
    }   

    const start = document.querySelector('.blue');
    start.addEventListener('click', startQuiz); 
    
function onResponse(response){
    return response.json();
    }
    

function convert(convert) {
    return convert.replace(/</g, "&lt").replace(/>/g, "&gt");
}

// move to screen 3
function submitAnswer(){
    const result = document.querySelector('#review-quiz');
    const erase = document.querySelector('.submit_answer');
    result.classList.remove('hidden');
    erase.classList.add('hidden');
    var c = document.querySelector('.option').children;
    

    // const opject = {
    //     "5f6bb58597518f0bc82e4231" : '',
    //     "5f6bb9db08aa20381c380708" :
    //     "5f6bb67997518f0bc82e4233" :
    //     "5f6bb79b97518f0bc82e4239" :
    //     "5f6bb7cb97518f0bc82e423a" :
    //     "5f6bb8cbd8d2fe3bf4028283" :
    //     "5f6bba1a44470627f8773da6" :
    //     "5f6bb90f309505421cde9ea5" : 
    //     "5f6bb894d9a1ce2cf0717212" :
    //     "5f6bb465933d010004ef1b13" :
    // }
    // const attemptId = document.querySelector('.green');
    // console.log(attemptId);
    fetch('https://wpr-quiz-api.herokuapp.com/attempts/'+ attemptId + '/submit',{
        method: 'POST',
        headers: { 'Content Type': 'application/json'
            },
        body: JSON.stringify(opject)
    }).then(onResponse).then(function onResult(result){
        const corAns = result.answers;
    });
    }

     const submit = document.querySelector('.green');
     submit.addEventListener('click', submitAnswer);
     
function highlight(event){
    
    const options = document.querySelectorAll('.option');
    for(let i = 0; i < options.length; i++){
        if(options[i].querySelector('input[type="radio"]').checked==true){
            options[i].classList.add('checked_label');
        }else{
            options[i].classList.remove('checked_label');
        }
    }
}
    const done = document.querySelector('.green');
    done.addEventListener('click', highlight);
